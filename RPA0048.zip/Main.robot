*** Settings ***
Library           OperatingSystem
Resource          ../RPA0048/Flows/Flows.robot


*** Tasks ***

robot file 
    Extract the data from the excel
    Read Directory And Execute Company Process

